#include "stdafx.h"
#include "Pracownik.h"
#include <iostream>
#include <string>


Pracownik::Pracownik(const char * im, const char * naz, int dzien, int miesiac, int rok)
	:m_Imie(im), m_Nazwisko(naz), m_DataUrodzenia(dzien, miesiac, rok)
{

}

Pracownik::Pracownik(const Pracownik & wzor)
{
	m_DataUrodzenia = Data(wzor.DataUrodzenia());
	m_Imie = wzor.m_Imie;
	m_Nazwisko = wzor.m_Nazwisko;
}

Pracownik & Pracownik::operator=(const Pracownik & wzor)
{
	m_DataUrodzenia = Data(wzor.DataUrodzenia());
	m_Imie = Napis(wzor.Imie());
	m_Nazwisko = Napis(wzor.Nazwisko());
	return *this;
}

bool Pracownik::operator==(const Pracownik & wzor) const
{
	if (Pracownik::Porownaj(wzor) == 0)
		return true;
	return false;
}

Pracownik::~Pracownik()
{
	delete m_pNastepny;
}

const char * Pracownik::Imie() const
{
	return m_Imie.Zwroc();
}

const char * Pracownik::Nazwisko() const
{
	return m_Nazwisko.Zwroc();
}

void Pracownik::Imie(const char * nowe_imie)
{
	this->m_Imie.Ustaw(nowe_imie);
}

void Pracownik::Nazwisko(const char * nowe_nazwisko)
{
	this->m_Nazwisko.Ustaw(nowe_nazwisko);
}

void Pracownik::DataUrodzenia(int nowy_dzien, int nowy_miesiac, int nowy_rok)
{
	this->m_DataUrodzenia.Ustaw(nowy_dzien, nowy_miesiac, nowy_rok);
}

Data Pracownik::DataUrodzenia() const
{
	return m_DataUrodzenia;
}

void Pracownik::Wypisz() const
{
	std::cout << Imie() << " " << Nazwisko() << " ";
	m_DataUrodzenia.Wypisz();
}

void Pracownik::Wpisz()
{
	std::cout << "Wpisz imie i nazwisko:";
	m_Imie.Wpisz();
	m_Nazwisko.Wpisz();
	m_DataUrodzenia.Wpisz();

}

int Pracownik::SprawdzImie(const char * por_imie) const
{
	return strcmp(Imie(), por_imie);
}

int Pracownik::SprawdzNazwisko(const char * por_nazwisko) const
{
	return strcmp(Nazwisko(), por_nazwisko);
}

int Pracownik::Porownaj(const Pracownik& wzorzec) const
{
	int sprawdz = SprawdzNazwisko(wzorzec.Nazwisko());
	if (sprawdz != 0)
		return sprawdz;

	sprawdz = SprawdzImie(wzorzec.Imie());
	if (sprawdz != 0)
		return sprawdz;

	sprawdz = this->DataUrodzenia().Porownaj(wzorzec.DataUrodzenia());
	if (sprawdz != 0)
		return sprawdz;
	return 0;
}
