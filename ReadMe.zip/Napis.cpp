#include "stdafx.h"
#include "Napis.h"
#include <string>
#include <iostream>

//disable strcpy warning
#pragma warning(disable:4996)


Napis::Napis(const char * nap)
{
	this->Ustaw(nap);
}

Napis::Napis(const Napis & wzor)
{

}

Napis::~Napis()
{
	delete m_pszNapis;
}

const char * Napis::Zwroc() const
{
	return this->m_pszNapis;
}

void Napis::Ustaw(const char * nowy_napis)
{
	int dl = strlen(nowy_napis);
	m_pszNapis = new char[dl];
	strcpy(m_pszNapis, nowy_napis);
	m_nDl = dl;
}

void Napis::Wypisz() const
{
	std::cout << this->Zwroc();
}

void Napis::Wpisz()
{
	std::string str;
	std::cin >> str;
	this->Ustaw(str.c_str());
}

int Napis::SprawdzNapis(const char * por_napis) const
{
	return strcmp(this->Zwroc(), por_napis);
}

Napis & Napis::operator=(const Napis & wzor)
{
	Ustaw(wzor.Zwroc());
	return *this;
}

bool Napis::operator==(const Napis & wzor) const
{
	if (Napis::SprawdzNapis(wzor.Zwroc()) == 0)
		return true;
	return false;
}

