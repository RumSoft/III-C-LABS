#include "stdafx.h"
#include <iostream>
#include "Data.h"
#include "Napis.h"
#include "Pracownik.h"
#include "ListaPracownikow.h"
using namespace std;

void test1() {
	Pracownik p1, p2, p3, p4;
	p1.Imie("JANUSZ"); p1.Nazwisko("MARIAN"); p1.DataUrodzenia(1, 1, 111);
	p2.Imie("BBBABA"); p2.Nazwisko("BAABABA"); p2.DataUrodzenia(1, 1, 11);
	p3.Imie("ALA"); p2.Nazwisko("MA_KOTA"); p2.DataUrodzenia(345, 31, 1939);
	p4.Imie("KOT"); p2.Nazwisko("ALI"); p2.DataUrodzenia(23, 5, 1945);
	int por = p1.Porownaj(p2);
	cout << por;

	ListaPracownikow* l = new ListaPracownikow();
	l->Dodaj(p1);
	l->WypiszPracownikow();
	l->Dodaj(p2);
	l->WypiszPracownikow();

	cout << "szukaj goscia ";
	auto p = l->Szukaj("MARIAN", "JANUSZ");
	if (p != nullptr) {
		cout << "\n znaleziono: \n";
		p->Wypisz();
		std::cout << endl;
	}

	l->Usun(p1);
	l->WypiszPracownikow();

	l->Dodaj(p3);
	l->Dodaj(p4);
	l->WypiszPracownikow();

	l->Usun(p1);
	l->Usun(p2);
	l->Usun(p3);
	l->Usun(p4);

	l->WypiszPracownikow();
}
int main() {
	Data d(10, 20, 30);
	test1();
	system("PAUSE");
}