#include "stdafx.h"
#include "Data.h"
#include <iostream>

using namespace std;


ostream & Data::operator<<(ostream & wy, const Data & d)
{
	return wy;
}

Data::Data(int d, int m, int r) : m_nDzien(d), m_nMiesiac(m), m_nRok(r)
{
}

Data::~Data()
{
}

int Data::Dzien() const
{
	return m_nDzien;
}

int Data::Miesiac() const
{
	return m_nMiesiac;
}

int Data::Rok() const
{
	return m_nRok;
}

void Data::Wypisz() const
{
	std::cout << m_nDzien << "-" << m_nMiesiac << "-" << m_nRok;
}

void Data::Wpisz()
{
	std::cout << "Wpisz date w formacie: dd mm rrrr" << std::endl;
	int d, m, r;
	std::cin >> d >> m >> r;
	Data::Ustaw(d, m, r);
}

void Data::Koryguj()
{
	if (m_nMiesiac > 12) m_nMiesiac = 12;
	else if (m_nMiesiac < 1) m_nMiesiac = 1;
	
	if (m_nDzien < 1)
		m_nDzien = 1;

	int dniNaMiesiac[] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	if (m_nDzien > dniNaMiesiac[m_nMiesiac - 1])
		m_nDzien = dniNaMiesiac[m_nMiesiac - 1];
	
	if (m_nMiesiac == 2 && m_nDzien == 29 && !Przestepny())
		m_nDzien = 28;

}

int Data::Porownaj(const Data & wzor) const
{
	int d1 = this->Rok() * 10000 + Miesiac() * 100 + this->Dzien();
	int d2 = wzor.Rok() * 10000 + wzor.Miesiac() * 100 + wzor.Dzien();
	if (d1 > d2)
		return 1;
	if (d1 < d2)
		return -1;
	return 0;
}

void Data::Ustaw(int d, int m, int r)
{
	m_nDzien = d;
	m_nMiesiac = m;
	m_nRok = r;
	Data::Koryguj();
}


bool Data::Przestepny()
{
	return (Rok() % 4 == 0 && Rok() % 100 != 0) || (Rok() % 400 == 0);
}
